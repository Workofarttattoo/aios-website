"""
Copyright (c) 2025 Joshua Hendricks Cole (DBA: Corporation of Light). All Rights Reserved. PATENT PENDING.

Scr1b3 GUI launcher.
"""

import http.server
import os
import socketserver
import webbrowser
from pathlib import Path


PORT = 8890


def launch_gui():
    """Launch the Scr1b3 web GUI."""
    gui_path = Path(__file__).parent / "scribe_gui.html"

    if not gui_path.exists():
        print("[error] GUI file not found:", gui_path)
        return 1

    class Handler(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=str(gui_path.parent), **kwargs)

        def log_message(self, format, *args):
            # Suppress logging
            pass

    try:
        with socketserver.TCPServer(("", PORT), Handler) as httpd:
            url = f"http://localhost:{PORT}/scribe_gui.html"
            print(f"[info] Scr1b3 GUI running at {url}")
            print("[info] Press Ctrl+C to stop")

            # Open browser
            webbrowser.open(url)

            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[info] Shutting down GUI server...")
    except OSError as e:
        if "Address already in use" in str(e):
            print(f"[error] Port {PORT} already in use")
            return 1
        raise

    return 0


if __name__ == "__main__":
    raise SystemExit(launch_gui())
